﻿namespace MockAssessment3
{
    public abstract class Villager
    {
        public int Hunger { get; set; }

        abstract public int Farm();
    }
}